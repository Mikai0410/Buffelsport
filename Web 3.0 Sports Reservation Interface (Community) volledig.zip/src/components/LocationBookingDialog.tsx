import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { BookingCalendar } from './BookingCalendar';
import { PaymentDialog } from './PaymentDialog';
import { PaymentConfirmation } from './PaymentConfirmation';

interface Location {
  id: number;
  name: string;
  address: string;
  city: string;
  distance: number;
  rating: number;
  sports: string[];
  priceRange: string;
  openNow: boolean;
  phone: string;
  lat: number;
  lng: number;
}

interface LocationBookingDialogProps {
  location: Location | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function LocationBookingDialog({ location, open, onOpenChange }: LocationBookingDialogProps) {
  const [showPayment, setShowPayment] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [bookingDetails, setBookingDetails] = useState<{
    date: Date;
    time: string;
  } | null>(null);

  const handleBookingConfirm = (date: Date, time: string) => {
    setBookingDetails({ date, time });
    setShowPayment(true);
  };

  const handlePaymentSuccess = () => {
    setShowPayment(false);
    setShowConfirmation(true);
  };

  const handleCloseConfirmation = () => {
    setShowConfirmation(false);
    setBookingDetails(null);
    onOpenChange(false);
  };

  if (!location) return null;

  // Calculate price (use middle of range)
  const priceMatch = location.priceRange.match(/€(\d+)-(\d+)/);
  const price = priceMatch 
    ? Math.round((parseInt(priceMatch[1]) + parseInt(priceMatch[2])) / 2)
    : 50;

  return (
    <>
      <Dialog open={open && !showPayment && !showConfirmation} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">
              Boek {location.name}
            </DialogTitle>
            <DialogDescription>
              {location.address}, {location.city} • {location.sports.join(', ')}
            </DialogDescription>
          </DialogHeader>
          <BookingCalendar
            fieldName={location.name}
            onConfirm={handleBookingConfirm}
          />
        </DialogContent>
      </Dialog>

      {showPayment && bookingDetails && (
        <PaymentDialog
          open={showPayment}
          onOpenChange={setShowPayment}
          amount={price}
          fieldName={location.name}
          date={bookingDetails.date.toLocaleDateString('nl-NL')}
          time={bookingDetails.time}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {showConfirmation && bookingDetails && (
        <PaymentConfirmation
          open={showConfirmation}
          onOpenChange={handleCloseConfirmation}
          fieldName={location.name}
          date={bookingDetails.date.toLocaleDateString('nl-NL')}
          time={bookingDetails.time}
          amount={price}
        />
      )}
    </>
  );
}