import { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Search, Navigation, Clock, Star, Euro, Phone } from 'lucide-react';
import { Button } from './ui/button';

interface Location {
  id: number;
  name: string;
  address: string;
  city: string;
  distance: number;
  rating: number;
  sports: string[];
  priceRange: string;
  openNow: boolean;
  phone: string;
  lat: number;
  lng: number;
}

const mockLocations: Location[] = [
  {
    id: 1,
    name: 'Central Basketball Arena',
    address: 'Sportlaan 10',
    city: 'Amsterdam',
    distance: 0.8,
    rating: 4.8,
    sports: ['Basketball', 'Volleyball'],
    priceRange: '€40-60',
    openNow: true,
    phone: '+31 20 123 4567',
    lat: 52.3702,
    lng: 4.8952,
  },
  {
    id: 2,
    name: 'Elite Padel Club',
    address: 'Tennisweg 25',
    city: 'Amsterdam',
    distance: 1.2,
    rating: 4.9,
    sports: ['Padel', 'Tennis'],
    priceRange: '€50-70',
    openNow: true,
    phone: '+31 20 234 5678',
    lat: 52.3676,
    lng: 4.9041,
  },
  {
    id: 3,
    name: 'Downtown Futsal Arena',
    address: 'Voetbalstraat 5',
    city: 'Amsterdam',
    distance: 2.1,
    rating: 4.7,
    sports: ['Futsal', 'Voetbal'],
    priceRange: '€45-65',
    openNow: true,
    phone: '+31 20 345 6789',
    lat: 52.3667,
    lng: 4.8945,
  },
  {
    id: 4,
    name: 'Premium Tennis Club',
    address: 'Racketlaan 15',
    city: 'Amsterdam',
    distance: 2.5,
    rating: 4.6,
    sports: ['Tennis', 'Squash'],
    priceRange: '€50-80',
    openNow: false,
    phone: '+31 20 456 7890',
    lat: 52.3600,
    lng: 4.8800,
  },
  {
    id: 5,
    name: 'Beachside Volleyball',
    address: 'Strandweg 99',
    city: 'Amsterdam',
    distance: 3.2,
    rating: 4.5,
    sports: ['Beachvolleybal', 'Volleyball'],
    priceRange: '€35-50',
    openNow: true,
    phone: '+31 20 567 8901',
    lat: 52.3750,
    lng: 4.9100,
  },
  {
    id: 6,
    name: 'Sportcentrum Zuid',
    address: 'Olympialaan 50',
    city: 'Amsterdam',
    distance: 3.8,
    rating: 4.4,
    sports: ['Basketball', 'Badminton', 'Voetbal'],
    priceRange: '€40-65',
    openNow: true,
    phone: '+31 20 678 9012',
    lat: 52.3580,
    lng: 4.8700,
  },
];

export function Locations() {
  const [searchLocation, setSearchLocation] = useState('');
  const [filteredLocations, setFilteredLocations] = useState(mockLocations);
  const [selectedSport, setSelectedSport] = useState('Alle');
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);

  const allSports = ['Alle', 'Basketball', 'Padel', 'Tennis', 'Futsal', 'Voetbal', 'Volleyball', 'Badminton'];

  const handleSearch = () => {
    let filtered = mockLocations;

    // Filter by sport
    if (selectedSport !== 'Alle') {
      filtered = filtered.filter(loc => loc.sports.includes(selectedSport));
    }

    // Filter by location/city name
    if (searchLocation) {
      filtered = filtered.filter(loc => 
        loc.city.toLowerCase().includes(searchLocation.toLowerCase()) ||
        loc.name.toLowerCase().includes(searchLocation.toLowerCase()) ||
        loc.address.toLowerCase().includes(searchLocation.toLowerCase())
      );
    }

    // Sort by distance
    filtered.sort((a, b) => a.distance - b.distance);

    setFilteredLocations(filtered);
  };

  const handleUseMyLocation = () => {
    // In a real app, this would use the Geolocation API
    // For now, we'll just simulate sorting by distance
    const sorted = [...filteredLocations].sort((a, b) => a.distance - b.distance);
    setFilteredLocations(sorted);
    setSearchLocation('Amsterdam');
  };

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl text-gray-900 mb-4">Vind sportlocaties bij jou in de buurt</h1>
          <p className="text-xl text-gray-600">
            Ontdek alle beschikbare sportfaciliteiten en boek direct jouw favoriete veld
          </p>
        </motion.div>

        {/* Search Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl shadow-lg p-6 mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Location Input */}
            <div className="md:col-span-5">
              <label className="block text-sm text-gray-600 mb-2">Locatie</label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Voer stad of postcode in"
                  value={searchLocation}
                  onChange={(e) => setSearchLocation(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sport-primary focus:border-transparent"
                />
              </div>
            </div>

            {/* Sport Filter */}
            <div className="md:col-span-4">
              <label className="block text-sm text-gray-600 mb-2">Sport</label>
              <select
                value={selectedSport}
                onChange={(e) => setSelectedSport(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-sport-primary focus:border-transparent"
              >
                {allSports.map(sport => (
                  <option key={sport} value={sport}>{sport}</option>
                ))}
              </select>
            </div>

            {/* Search Button */}
            <div className="md:col-span-3 flex items-end gap-2">
              <Button
                onClick={handleSearch}
                className="flex-1 bg-sport-primary text-white hover:bg-sport-primary/90 h-[46px]"
              >
                <Search className="w-4 h-4 mr-2" />
                Zoeken
              </Button>
              <Button
                onClick={handleUseMyLocation}
                variant="outline"
                className="h-[46px] px-3"
                title="Gebruik mijn locatie"
              >
                <Navigation className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Location List */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl text-gray-900">
                {filteredLocations.length} locaties gevonden
              </h2>
            </div>

            {filteredLocations.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
                <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl text-gray-900 mb-2">Geen locaties gevonden</h3>
                <p className="text-gray-600">
                  Probeer een andere locatie of sport te selecteren
                </p>
              </div>
            ) : (
              filteredLocations.map((location, index) => (
                <motion.div
                  key={location.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all cursor-pointer ${
                    selectedLocation?.id === location.id ? 'ring-2 ring-sport-primary' : ''
                  }`}
                  onClick={() => setSelectedLocation(location)}
                >
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="text-xl text-gray-900">{location.name}</h3>
                          {location.openNow && (
                            <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                              Open
                            </span>
                          )}
                        </div>
                        <p className="text-gray-600 flex items-center gap-1 mb-1">
                          <MapPin className="w-4 h-4" />
                          {location.address}, {location.city}
                        </p>
                        <p className="text-gray-500 text-sm">
                          {location.distance} km afstand
                        </p>
                      </div>
                      <div className="flex items-center gap-1 bg-yellow-50 px-3 py-1 rounded-lg">
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                        <span className="text-gray-900">{location.rating}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {location.sports.map(sport => (
                        <span
                          key={sport}
                          className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm"
                        >
                          {sport}
                        </span>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <Euro className="w-4 h-4" />
                          {location.priceRange}
                        </span>
                        <span className="flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          {location.phone}
                        </span>
                      </div>
                      <Button
                        onClick={(e) => {
                          e.stopPropagation();
                          // Handle booking
                        }}
                        className="bg-sport-primary text-white hover:bg-sport-primary/90"
                      >
                        Boek nu
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>

          {/* Map */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="sticky top-24"
            >
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div className="h-[600px] relative">
                  {/* Google Maps Placeholder */}
                  <div className="w-full h-full bg-gradient-to-br from-blue-100 via-blue-50 to-green-50 relative">
                    {/* Map Grid */}
                    <div className="absolute inset-0 opacity-20">
                      <div className="grid grid-cols-8 grid-rows-8 h-full">
                        {[...Array(64)].map((_, i) => (
                          <div key={i} className="border border-gray-300" />
                        ))}
                      </div>
                    </div>

                    {/* Location Markers */}
                    {filteredLocations.map((location, index) => {
                      const top = 20 + (index * 12) % 60;
                      const left = 15 + (index * 15) % 70;
                      
                      return (
                        <motion.div
                          key={location.id}
                          initial={{ scale: 0 }}
                          animate={{ scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                          className={`absolute cursor-pointer ${
                            selectedLocation?.id === location.id ? 'z-10' : ''
                          }`}
                          style={{ top: `${top}%`, left: `${left}%` }}
                          onClick={() => setSelectedLocation(location)}
                        >
                          <div className={`relative group`}>
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-all ${
                              selectedLocation?.id === location.id
                                ? 'bg-sport-primary scale-125'
                                : 'bg-white hover:scale-110'
                            }`}>
                              <MapPin className={`w-5 h-5 ${
                                selectedLocation?.id === location.id ? 'text-white' : 'text-sport-primary'
                              }`} />
                            </div>
                            
                            {/* Tooltip */}
                            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                              <div className="bg-gray-900 text-white text-xs rounded-lg px-3 py-2 whitespace-nowrap">
                                {location.name}
                                <div className="text-gray-400">{location.distance} km</div>
                              </div>
                              <div className="w-2 h-2 bg-gray-900 transform rotate-45 absolute top-full left-1/2 -translate-x-1/2 -translate-y-1/2" />
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}

                    {/* Center User Location Indicator */}
                    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                        className="w-4 h-4 bg-blue-500 rounded-full border-4 border-white shadow-lg"
                      />
                    </div>

                    {/* Map Overlay Text */}
                    <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-4">
                      <p className="text-sm text-gray-600 mb-1">
                        {selectedLocation ? (
                          <>
                            <span className="text-gray-900">
                              {selectedLocation.name}
                            </span>
                            <br />
                            {selectedLocation.address}, {selectedLocation.city}
                          </>
                        ) : (
                          'Selecteer een locatie om details te zien'
                        )}
                      </p>
                      {selectedLocation && (
                        <p className="text-xs text-gray-500">
                          {selectedLocation.distance} km afstand
                        </p>
                      )}
                    </div>

                    {/* Map Note */}
                    <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg px-3 py-2">
                      <p className="text-xs text-gray-600">
                        📍 Interactieve kaart demo
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
