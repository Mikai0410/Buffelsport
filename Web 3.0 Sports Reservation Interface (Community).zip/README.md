
  # Web 3.0 Sports Reservation Interface (Community)

  This is a code bundle for Web 3.0 Sports Reservation Interface (Community). The original project is available at https://www.figma.com/design/NO1djZ0WBuoZ1Hs6SV9fLG/Web-3.0-Sports-Reservation-Interface--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  